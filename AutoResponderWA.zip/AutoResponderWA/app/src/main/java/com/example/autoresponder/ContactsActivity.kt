package com.example.autoresponder

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.provider.ContactsContract
import android.widget.*

class ContactsActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var boxes: List<LinearLayout>

    private fun get(which: Int) = if (which == 0) prefs.excluded else prefs.only
    private fun put(which: Int, v: String) { if (which == 0) prefs.excluded = v else prefs.only = v }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Contactos"
        prefs = Prefs(this)
        val col = Ui.page(this)

        col.addView(Ui.title(this, "🚫 No responder a"))
        col.addView(Ui.note(this, "A estas personas nunca se les responde automáticamente."))
        val b0 = LinearLayout(this); b0.orientation = LinearLayout.VERTICAL
        col.addView(b0)
        addButtons(col, 0)

        col.addView(Ui.title(this, "✅ Responder SOLO a"))
        col.addView(Ui.note(this, "Si agregás a alguien acá, la app responde únicamente a esas personas. Si la lista está vacía, responde a todos."))
        val b1 = LinearLayout(this); b1.orientation = LinearLayout.VERTICAL
        col.addView(b1)
        addButtons(col, 1)

        boxes = listOf(b0, b1)
        refresh()
    }

    private fun addButtons(col: LinearLayout, which: Int) {
        col.addView(Ui.btn(this, "📇 Elegir de mis contactos") {
            startActivityForResult(
                Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI),
                200 + which
            )
        })
        col.addView(Ui.btn(this, "✍️ Escribir nombre o número") { manualDialog(which) })
    }

    private fun manualDialog(which: Int) {
        val et = EditText(this)
        et.hint = "Nombre o número"
        AlertDialog.Builder(this).setTitle("Agregar contacto").setView(et)
            .setPositiveButton("Agregar") { _, _ ->
                val s = et.text.toString().trim()
                if (s.isNotEmpty()) {
                    val digits = s.filter { it.isDigit() }
                    if (digits.length >= 6 && s.none { it.isLetter() }) addEntry(which, "", digits)
                    else addEntry(which, s, "")
                }
            }
            .setNegativeButton("Cancelar", null).show()
    }

    private fun addEntry(which: Int, name: String, digits: String) {
        put(which, ContactList.add(get(which), name, digits))
        refresh()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data ?: return
        if (resultCode != RESULT_OK) return
        val which = requestCode - 200
        if (which !in 0..1) return
        val cols = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )
        contentResolver.query(uri, cols, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                addEntry(which, c.getString(0) ?: "", (c.getString(1) ?: "").filter { it.isDigit() })
            }
        }
    }

    private fun refresh() {
        for (which in 0..1) {
            val box = boxes[which]
            box.removeAllViews()
            val entries = ContactList.parse(get(which))
            if (entries.isEmpty()) {
                box.addView(TextView(this).also { it.text = "(vacío)"; it.setPadding(0, 8, 0, 8) })
            }
            entries.forEachIndexed { i, e ->
                val row = LinearLayout(this)
                val tv = TextView(this)
                tv.text = ContactList.label(e)
                tv.textSize = 16f
                tv.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                val del = Ui.btn(this, "✕") {
                    put(which, ContactList.removeAt(get(which), i))
                    refresh()
                }
                row.addView(tv)
                row.addView(del)
                box.addView(row)
            }
        }
    }
}
