package com.example.autoresponder

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.*

class RulesActivity : Activity() {

    private lateinit var list: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Mensajes y menús"
        val col = Ui.page(this)
        col.addView(Ui.note(this,
            "Cada regla es un mensaje que el cliente recibe. ⭐ es el menú principal: " +
            "lo primero que ve. Tocá una regla para editarla."))
        col.addView(Ui.btn(this, "➕ Agregar regla") {
            startActivity(Intent(this, NodeEditActivity::class.java))
        })
        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        col.addView(list)
    }

    override fun onResume() {
        super.onResume()
        list.removeAllViews()
        val nodes = Store.load(Prefs(this))
        nodes.forEachIndexed { i, n ->
            val tv = TextView(this)
            val star = if (i == 0) "⭐ " else ""
            val what = when {
                n.id == FALLBACK_ID -> "Mensaje cuando no entiende"
                n.triggers.isNotEmpty() -> "Si dicen: " + n.triggers.take(4).joinToString(", ")
                else -> "Se llega desde un botón del menú"
            }
            val opts = if (n.options.isNotEmpty()) " · ${n.options.size} opciones" else ""
            tv.text = star + n.name + "\n" + what + opts
            tv.textSize = 15f
            val p = Ui.dp(this, 12)
            tv.setPadding(p, p, p, p)
            tv.setBackgroundColor(0xFFEEEEEE.toInt())
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.topMargin = Ui.dp(this, 8)
            tv.layoutParams = lp
            tv.setOnClickListener {
                startActivity(Intent(this, NodeEditActivity::class.java).putExtra("id", n.id))
            }
            list.addView(tv)
        }
    }
}
