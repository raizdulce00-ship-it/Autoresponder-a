package com.example.autoresponder

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.*

class MainActivity : Activity() {

    private lateinit var permTv: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Autorespondedor"
        val prefs = Prefs(this)
        val col = Ui.page(this)

        val sw = Switch(this)
        sw.text = "Respuestas automáticas"
        sw.textSize = 18f
        sw.isChecked = prefs.enabled
        sw.setOnCheckedChangeListener { _, c -> prefs.enabled = c }
        col.addView(sw)

        permTv = TextView(this)
        col.addView(permTv)
        col.addView(Ui.btn(this, "🔔 Dar permiso de notificaciones") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })

        col.addView(Ui.title(this, "¿En qué app responder?"))
        val wa = CheckBox(this)
        wa.text = "WhatsApp"
        wa.isChecked = prefs.useWa
        wa.setOnCheckedChangeListener { _, c -> prefs.useWa = c }
        val biz = CheckBox(this)
        biz.text = "WhatsApp Business"
        biz.isChecked = prefs.useBiz
        biz.setOnCheckedChangeListener { _, c -> prefs.useBiz = c }
        col.addView(wa)
        col.addView(biz)

        col.addView(Ui.title(this, "Qué responder"))
        col.addView(Ui.btn(this, "💬 Mensajes y menús") {
            startActivity(Intent(this, RulesActivity::class.java))
        })
        col.addView(Ui.btn(this, "🚫 Contactos (a quién sí / a quién no)") {
            startActivity(Intent(this, ContactsActivity::class.java))
        })
        col.addView(Ui.btn(this, "📝 Cargar reglas en formato notas") {
            startActivity(Intent(this, NotesActivity::class.java))
        })
        col.addView(Ui.btn(this, "🧪 Probar cómo responde") {
            startActivity(Intent(this, TestActivity::class.java))
        })
        col.addView(Ui.btn(this, "⚙️ Ajustes (tiempos y horario)") { settingsDialog(prefs) })
    }

    override fun onResume() {
        super.onResume()
        val on = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
            ?.contains(packageName) == true
        permTv.text = if (on) "✅ Permiso de notificaciones dado"
        else "❌ Falta el permiso: tocá el botón y activá Autorespondedor"
    }

    private fun settingsDialog(prefs: Prefs) {
        val pad = Ui.dp(this, 16)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(pad, pad, pad, pad)
        fun field(label: String, v: Int): EditText {
            box.addView(TextView(this).also { it.text = label })
            val et = EditText(this)
            et.setText(v.toString())
            et.inputType = InputType.TYPE_CLASS_NUMBER
            box.addView(et)
            return et
        }
        val sec = field("Segundos de espera entre respuestas al mismo contacto", prefs.minSeconds)
        val ses = field("Minutos que dura la conversación del menú", prefs.sessionMin)
        val from = field("Responder desde la hora (0-23)", prefs.hourFrom)
        val to = field("hasta la hora (0-23). Si son iguales, responde todo el día", prefs.hourTo)
        AlertDialog.Builder(this).setTitle("Ajustes")
            .setView(ScrollView(this).also { it.addView(box) })
            .setPositiveButton("Guardar") { _, _ ->
                prefs.minSeconds = (sec.text.toString().toIntOrNull() ?: 2).coerceAtLeast(0)
                prefs.sessionMin = (ses.text.toString().toIntOrNull() ?: 30).coerceAtLeast(1)
                prefs.hourFrom = (from.text.toString().toIntOrNull() ?: 0).coerceIn(0, 23)
                prefs.hourTo = (to.text.toString().toIntOrNull() ?: 0).coerceIn(0, 23)
            }
            .setNegativeButton("Cancelar", null).show()
    }
}
