package com.example.autoresponder

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {

    private val help = """
Cada pantalla empieza con @nombre.
La primera (o la llamada @inicio) es el menú principal.

? palabras, separadas, por comas
→ si el cliente escribe alguna, se muestra esta pantalla.

> tecla | texto | destino
→ opción del menú. Ej: > 1 | Precios | precios

El resto de las líneas es el mensaje: podés usar emojis, links y {nombre}.

@fallback = mensaje cuando no entiende.
Líneas con // son comentarios.

El cliente escribe 0 para volver y # para ir al menú principal.
Para una imagen, pegá el link directo (https://...jpg).
""".trimIndent()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = Prefs(this)
        val pad = (16 * resources.displayMetrics.density).toInt()

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        fun label(t: String) = TextView(this).apply {
            text = t
            setPadding(0, pad, 0, 0)
            setTypeface(null, Typeface.BOLD)
        }
        fun num(v: Int) = EditText(this).apply {
            setText(v.toString())
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        fun multi(v: String, lines: Int) = EditText(this).apply {
            setText(v)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = lines
            gravity = Gravity.TOP
        }

        val permBtn = Button(this).apply {
            text = "1) Dar acceso a notificaciones"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
        }
        val switch = Switch(this).apply {
            text = "Respuesta automática activada"
            isChecked = prefs.enabled
        }

        val scriptEt = multi(prefs.script, 16).apply {
            typeface = Typeface.MONOSPACE
            textSize = 13f
        }
        val helpBtn = Button(this).apply {
            text = "Ver formato del menú"
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity).setMessage(help)
                    .setPositiveButton("OK", null).show()
            }
        }
        val excludedEt = multi(prefs.excluded, 3)
        val onlyEt = multi(prefs.only, 3)
        val secEt = num(prefs.minSeconds)
        val sessEt = num(prefs.sessionMin)
        val fromEt = num(prefs.hourFrom)
        val toEt = num(prefs.hourTo)

        val save = Button(this).apply {
            text = "2) Guardar"
            setOnClickListener {
                prefs.enabled = switch.isChecked
                prefs.script = scriptEt.text.toString()
                prefs.excluded = excludedEt.text.toString()
                prefs.only = onlyEt.text.toString()
                prefs.minSeconds = (secEt.text.toString().toIntOrNull() ?: 2).coerceAtLeast(0)
                prefs.sessionMin = (sessEt.text.toString().toIntOrNull() ?: 30).coerceAtLeast(1)
                prefs.hourFrom = (fromEt.text.toString().toIntOrNull() ?: 0).coerceIn(0, 23)
                prefs.hourTo = (toEt.text.toString().toIntOrNull() ?: 0).coerceIn(0, 23)
                Toast.makeText(this@MainActivity, "Guardado", Toast.LENGTH_SHORT).show()
            }
        }

        // Simulador para probar el menú sin WhatsApp
        val testEt = EditText(this).apply { hint = "Escribí como si fueras el cliente" }
        val outTv = TextView(this).apply {
            setTextIsSelectable(true)
            setPadding(pad / 2, pad / 2, pad / 2, pad / 2)
        }
        val testBtn = Button(this).apply {
            text = "Probar"
            setOnClickListener {
                val sc = Parser.parse(scriptEt.text.toString())
                val r = Engine.reply("__sim__", "Cliente", testEt.text.toString(), sc, 30 * 60_000L)
                outTv.text = r ?: "(no respondería)"
                testEt.setText("")
            }
        }
        val resetBtn = Button(this).apply {
            text = "Reiniciar conversación de prueba"
            setOnClickListener { Engine.reset("__sim__"); outTv.text = "" }
        }

        col.addView(permBtn)
        col.addView(switch)
        col.addView(label("Menú y reglas"))
        col.addView(scriptEt)
        col.addView(helpBtn)
        col.addView(label("Contactos excluidos (uno por línea: nombre o número)"))
        col.addView(excludedEt)
        col.addView(label("Responder SOLO a estos contactos (vacío = a todos)"))
        col.addView(onlyEt)
        col.addView(label("Segundos mínimos entre respuestas al mismo contacto"))
        col.addView(secEt)
        col.addView(label("Minutos que dura la conversación del menú"))
        col.addView(sessEt)
        col.addView(label("Responder desde la hora (0-23)"))
        col.addView(fromEt)
        col.addView(label("hasta la hora (0-23). Si son iguales, responde todo el día"))
        col.addView(toEt)
        col.addView(save)
        col.addView(label("Probar el menú"))
        col.addView(testEt)
        col.addView(testBtn)
        col.addView(outTv)
        col.addView(resetBtn)

        setContentView(ScrollView(this).apply {
            addView(col, ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        })
    }
}
