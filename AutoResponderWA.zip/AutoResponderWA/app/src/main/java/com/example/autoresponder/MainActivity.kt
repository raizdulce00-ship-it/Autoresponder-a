package com.example.autoresponder

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = Prefs(this)
        val pad = (16 * resources.displayMetrics.density).toInt()

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        fun label(t: String) = TextView(this).apply { text = t; setPadding(0, pad, 0, 0) }

        val switch = Switch(this).apply {
            text = "Respuesta automática activada"
            isChecked = prefs.enabled
        }
        val permBtn = Button(this).apply {
            text = "1) Dar acceso a notificaciones"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
        }
        val defaultEt = EditText(this).apply { setText(prefs.defaultReply) }
        val rulesEt = EditText(this).apply {
            setText(prefs.rules)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 4
        }
        val cooldownEt = EditText(this).apply {
            setText(prefs.cooldownMin.toString())
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        val save = Button(this).apply {
            text = "2) Guardar"
            setOnClickListener {
                prefs.enabled = switch.isChecked
                prefs.defaultReply = defaultEt.text.toString()
                prefs.rules = rulesEt.text.toString()
                prefs.cooldownMin = cooldownEt.text.toString().toIntOrNull() ?: 60
                Toast.makeText(this@MainActivity, "Guardado", Toast.LENGTH_SHORT).show()
            }
        }

        col.addView(permBtn)
        col.addView(switch)
        col.addView(label("Respuesta por defecto (vacía = no responder si no hay regla)"))
        col.addView(defaultEt)
        col.addView(label("Reglas, una por línea: palabra=respuesta"))
        col.addView(rulesEt)
        col.addView(label("Minutos sin volver a responder al mismo contacto"))
        col.addView(cooldownEt)
        col.addView(save)

        setContentView(ScrollView(this).apply {
            addView(col, ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        })
    }
}
