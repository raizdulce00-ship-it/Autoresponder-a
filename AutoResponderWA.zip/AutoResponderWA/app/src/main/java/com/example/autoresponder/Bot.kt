package com.example.autoresponder

import java.text.Normalizer

data class Option(val key: String, val label: String, val target: String)
data class Node(val id: String, val text: String, val triggers: List<String>, val options: List<Option>)
class Script(val nodes: Map<String, Node>, val rootId: String)

/** Minúsculas, sin tildes ni símbolos/emojis: "¡Hola! 👋" -> "hola" */
fun norm(s: String): String {
    val d = Normalizer.normalize(s, Normalizer.Form.NFD)
    return d.replace(Regex("\\p{M}+"), "")
        .lowercase()
        .replace(Regex("[^a-z0-9]+"), " ")
        .trim()
}

fun flat(s: String): String = norm(s).replace(" ", "")

object Parser {
    fun parse(src: String): Script {
        val nodes = LinkedHashMap<String, Node>()
        var id: String? = null
        var text = StringBuilder()
        var triggers = ArrayList<String>()
        var options = ArrayList<Option>()

        fun close() {
            val cur = id ?: return
            nodes[cur] = Node(cur, text.toString().trim(), triggers.toList(), options.toList())
        }

        for (raw in src.lines()) {
            val line = raw.trimEnd()
            val t = line.trim()
            if (t.startsWith("//")) continue
            if (t.startsWith("@")) {
                close()
                id = t.substring(1).trim().lowercase()
                text = StringBuilder()
                triggers = ArrayList()
                options = ArrayList()
                continue
            }
            if (id == null) continue
            when {
                t.startsWith("?") ->
                    t.substring(1).split(",").map { norm(it) }.filter { it.isNotEmpty() }
                        .forEach { triggers.add(it) }
                t.startsWith(">") -> {
                    val p = t.substring(1).split("|").map { it.trim() }
                    if (p.size >= 3 && p[0].isNotEmpty()) options.add(Option(p[0], p[1], p[2].lowercase()))
                }
                else -> text.appendLine(line)
            }
        }
        close()
        val root = if (nodes.containsKey("inicio")) "inicio" else (nodes.keys.firstOrNull() ?: "inicio")
        return Script(nodes, root)
    }
}

class Session(var node: String, val stack: ArrayList<String>, var time: Long)

object Engine {
    private val sessions = HashMap<String, Session>()

    fun reset(contact: String) { sessions.remove(contact) }

    private fun matches(triggers: List<String>, m: String): Boolean {
        val words = m.split(" ")
        val padded = " $m "
        return triggers.any { t ->
            if (t.contains(' ')) padded.contains(" $t ") else words.any { it.startsWith(t) }
        }
    }

    private fun keycap(k: String): String =
        if (k.length == 1 && k[0].isDigit()) k + "\uFE0F\u20E3" else "$k)"

    private fun render(node: Node, script: Script, name: String): String {
        val sb = StringBuilder(node.text.replace("{nombre}", name))
        if (node.options.isNotEmpty()) {
            if (sb.isNotEmpty()) sb.append("\n\n")
            node.options.forEachIndexed { i, o ->
                if (i > 0) sb.append("\n")
                sb.append(keycap(o.key)).append(" ").append(o.label)
            }
        }
        if (node.id != script.rootId) {
            sb.append("\n\n0\uFE0F\u20E3 Volver · #\uFE0F\u20E3 Menú principal")
        }
        return sb.toString().trim()
    }

    /** Devuelve el texto a responder, o null si no hay que responder. */
    fun reply(contact: String, name: String, message: String, script: Script, sessionMs: Long): String? {
        if (script.nodes.isEmpty()) return null
        val raw = message.trim()
        val m = norm(raw)
        val goRoot = raw.startsWith("#")
        if (m.isEmpty() && !goRoot) return null // solo emojis / stickers: se ignora

        val now = System.currentTimeMillis()
        val root = script.rootId
        val existing = sessions[contact]?.takeIf { now - it.time <= sessionMs }
        val sess: Session
        var unknown = false

        if (existing == null) {
            val first = if (goRoot) root
            else (script.nodes.values.firstOrNull { matches(it.triggers, m) }?.id ?: root)
            sess = Session(first, ArrayList(), now)
            sessions[contact] = sess
        } else {
            sess = existing
            val cur = script.nodes[sess.node]
            val opt = cur?.options?.firstOrNull { norm(it.key) == m || norm(it.label) == m }
            when {
                goRoot -> { sess.stack.clear(); sess.node = root }
                (m == "0" || m == "volver" || m == "atras") && sess.node != root ->
                    sess.node = if (sess.stack.isEmpty()) root else sess.stack.removeAt(sess.stack.size - 1)
                opt != null && script.nodes.containsKey(opt.target) -> {
                    sess.stack.add(sess.node)
                    sess.node = opt.target
                }
                else -> {
                    val t = script.nodes.values.firstOrNull { matches(it.triggers, m) }
                    if (t != null) {
                        sess.stack.clear()
                        if (t.id != root) sess.stack.add(root)
                        sess.node = t.id
                    } else unknown = true
                }
            }
            sess.time = now
        }

        val node = script.nodes[sess.node] ?: return null
        val body = render(node, script, name)
        if (!unknown) return body
        val fb = script.nodes["fallback"]?.text?.takeIf { it.isNotBlank() }
            ?: "No entendí tu mensaje 😅 Probá con una de estas opciones:"
        return fb.replace("{nombre}", name) + "\n\n" + body
    }
}
