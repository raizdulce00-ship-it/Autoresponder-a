package com.example.autoresponder

import android.app.Notification
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class WhatsAppReplyService : NotificationListenerService() {

    private val lastReply = HashMap<String, Long>()
    private val packages = setOf("com.whatsapp", "com.whatsapp.w4b")

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName !in packages) return
        val prefs = Prefs(this)
        if (!prefs.enabled) return

        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val extras = n.extras
        if (extras.getBoolean("android.isGroupConversation")) return // ignora grupos

        val title = extras.getString(Notification.EXTRA_TITLE) ?: return
        if (title == "WhatsApp" || title == "WhatsApp Business") return // resúmenes
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: return

        // Evita responder más de una vez por contacto dentro del tiempo de espera
        val now = System.currentTimeMillis()
        val last = lastReply[title] ?: 0L
        if (now - last < prefs.cooldownMin * 60_000L) return

        val reply = chooseReply(text, prefs) ?: return

        // Busca la acción "Responder" de la notificación
        val actions = (n.actions?.toList().orEmpty()) +
            Notification.WearableExtender(n).actions
        val action = actions.firstOrNull { it.remoteInputs?.isNotEmpty() == true } ?: return

        val remoteInputs = action.remoteInputs
        val results = Bundle().apply {
            putCharSequence(remoteInputs[0].resultKey, reply)
        }
        val intent = Intent()
        RemoteInput.addResultsToIntent(remoteInputs, intent, results)
        try {
            action.actionIntent.send(this, 0, intent)
            lastReply[title] = now
        } catch (e: PendingIntent.CanceledException) {
            // la notificación ya no existe
        }
    }

    private fun chooseReply(message: String, prefs: Prefs): String? {
        val msg = message.lowercase()
        for (line in prefs.rules.lines()) {
            val i = line.indexOf('=')
            if (i <= 0) continue
            val key = line.substring(0, i).trim().lowercase()
            val answer = line.substring(i + 1).trim()
            if (key.isNotEmpty() && answer.isNotEmpty() && msg.contains(key)) return answer
        }
        return prefs.defaultReply.takeIf { it.isNotBlank() }
    }
}
