package com.example.autoresponder

import android.app.Notification
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.util.Calendar

class WhatsAppReplyService : NotificationListenerService() {

    private val packages = setOf("com.whatsapp", "com.whatsapp.w4b")
    private val lastSent = HashMap<String, Long>()
    private val lastSentNorm = HashMap<String, String>()
    private val lastMsgTime = HashMap<String, Long>()
    private val lastText = HashMap<String, String>()
    private val lastTextAt = HashMap<String, Long>()

    @Suppress("DEPRECATION")
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName !in packages) return
        val prefs = Prefs(this)
        if (!prefs.enabled) return

        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val extras = n.extras
        if (extras.getBoolean("android.isGroupConversation")) return // ignora grupos

        val title = extras.getString(Notification.EXTRA_TITLE) ?: return
        if (title == "WhatsApp" || title == "WhatsApp Business") return

        // Último mensaje de la conversación
        var text: String? = null
        var msgTime = 0L
        val last = extras.getParcelableArray(Notification.EXTRA_MESSAGES)?.lastOrNull() as? Bundle
        if (last != null) {
            text = last.getCharSequence("text")?.toString()
            msgTime = last.getLong("time", 0L)
        }
        if (text == null) text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()
        val msg = text ?: return
        if (msg.isBlank()) return

        val key = sbn.packageName + "|" + title
        val now = System.currentTimeMillis()

        // No procesar dos veces el mismo mensaje
        if (msgTime > 0) {
            if (msgTime <= (lastMsgTime[key] ?: 0L)) return
            lastMsgTime[key] = msgTime
        } else {
            if (msg == lastText[key] && now - (lastTextAt[key] ?: 0L) < 3000) return
            lastText[key] = msg
            lastTextAt[key] = now
        }

        // No responderse a sí mismo
        if (norm(msg) == lastSentNorm[key]) return

        // Segundos mínimos entre respuestas al mismo contacto
        if (now - (lastSent[key] ?: 0L) < prefs.minSeconds * 1000L) return

        // Horario
        val from = prefs.hourFrom
        val to = prefs.hourTo
        if (from != to) {
            val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
            val ok = if (from < to) h in from until to else (h >= from || h < to)
            if (!ok) return
        }

        // Excluidos / solo estos
        val name = flat(title)
        val excluded = prefs.excluded.lines().map { flat(it) }.filter { it.isNotEmpty() }
        if (excluded.any { name.contains(it) }) return
        val only = prefs.only.lines().map { flat(it) }.filter { it.isNotEmpty() }
        if (only.isNotEmpty() && only.none { name.contains(it) }) return

        val reply = Engine.reply(
            key, title, msg, Parser.parse(prefs.script), prefs.sessionMin * 60_000L
        ) ?: return

        val actions = (n.actions?.toList().orEmpty()) + Notification.WearableExtender(n).actions
        val action = actions.firstOrNull { it.remoteInputs?.isNotEmpty() == true } ?: return

        val remoteInputs = action.remoteInputs
        val results = Bundle().apply { putCharSequence(remoteInputs[0].resultKey, reply) }
        val intent = Intent()
        RemoteInput.addResultsToIntent(remoteInputs, intent, results)
        try {
            action.actionIntent.send(this, 0, intent)
            lastSent[key] = now
            lastSentNorm[key] = norm(reply)
        } catch (e: PendingIntent.CanceledException) {
            // la notificación ya no existe
        }
    }
}
