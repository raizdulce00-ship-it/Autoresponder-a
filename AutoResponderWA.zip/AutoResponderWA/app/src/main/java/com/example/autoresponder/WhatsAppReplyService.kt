package com.example.autoresponder

import android.app.Notification
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.util.Calendar
import java.util.concurrent.ConcurrentHashMap

class WhatsAppReplyService : NotificationListenerService() {

    private val lastSent = ConcurrentHashMap<String, Long>()
    private val lastSentNorm = ConcurrentHashMap<String, String>()
    private val lastMsgTime = ConcurrentHashMap<String, Long>()
    private val lastText = ConcurrentHashMap<String, String>()
    private val lastTextAt = ConcurrentHashMap<String, Long>()

    @Suppress("DEPRECATION")
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val prefs = Prefs(this)
        if (!prefs.enabled) return
        val okPkg = (sbn.packageName == "com.whatsapp" && prefs.useWa) ||
            (sbn.packageName == "com.whatsapp.w4b" && prefs.useBiz)
        if (!okPkg) return

        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val extras = n.extras
        if (extras.getBoolean("android.isGroupConversation")) return // ignora grupos

        val title = extras.getString(Notification.EXTRA_TITLE) ?: return
        if (title == "WhatsApp" || title == "WhatsApp Business") return

        // Último mensaje de la conversación
        var text: String? = null
        var msgTime = 0L
        val last = extras.getParcelableArray(Notification.EXTRA_MESSAGES)?.lastOrNull() as? Bundle
        if (last != null) {
            text = last.getCharSequence("text")?.toString()
            msgTime = last.getLong("time", 0L)
        }
        if (text == null) text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()
        val msg = text ?: return
        if (msg.isBlank()) return

        val key = sbn.packageName + "|" + title
        val now = System.currentTimeMillis()

        // No procesar dos veces el mismo mensaje
        if (msgTime > 0) {
            if (msgTime <= (lastMsgTime[key] ?: 0L)) return
            lastMsgTime[key] = msgTime
        } else {
            if (msg == lastText[key] && now - (lastTextAt[key] ?: 0L) < 3000) return
            lastText[key] = msg
            lastTextAt[key] = now
        }

        // No responderse a sí mismo: después de responder, WhatsApp vuelve a avisar
        // con nuestro propio mensaje y se leería como si fuera del cliente.
        val sentAt = lastSent[key] ?: 0L
        val sentNorm = lastSentNorm[key] ?: ""
        val nMsg = norm(msg)
        val echoByTime = sentAt > 0 && (
            if (msgTime > 0) (msgTime - sentAt) in -1000L..2500L else (now - sentAt) < 2500L
        )
        val echoByText = sentNorm.isNotEmpty() && now - sentAt < 120_000L && nMsg.length >= 12 &&
            (sentNorm.contains(nMsg) || nMsg.contains(sentNorm.take(30)))
        if (echoByTime || echoByText) return

        // Segundos mínimos entre respuestas al mismo contacto
        if (now - (lastSent[key] ?: 0L) < prefs.minSeconds * 1000L) return

        // Horario
        val from = prefs.hourFrom
        val to = prefs.hourTo
        if (from != to) {
            val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
            val ok = if (from < to) h in from until to else (h >= from || h < to)
            if (!ok) return
        }

        // Contactos excluidos / solo estos
        if (ContactList.matches(prefs.excluded, title)) return
        if (prefs.only.isNotBlank() && !ContactList.matches(prefs.only, title)) return

        // Botón "Responder" de la notificación
        val actions = (n.actions?.toList().orEmpty()) + Notification.WearableExtender(n).actions
        val action = actions.firstOrNull { it.remoteInputs?.isNotEmpty() == true } ?: return

        val reply = Engine.reply(
            key, title, msg, Parser.parse(prefs.script), prefs.sessionMin * 60_000L
        ) ?: return

        val remoteInputs = action.remoteInputs
        val results = Bundle().apply { putCharSequence(remoteInputs[0].resultKey, reply) }
        val intent = Intent()
        RemoteInput.addResultsToIntent(remoteInputs, intent, results)
        try {
            action.actionIntent.send(this, 0, intent)
            lastSent[key] = System.currentTimeMillis()
            lastSentNorm[key] = norm(reply)
        } catch (e: PendingIntent.CanceledException) {
            // la notificación ya no existe
        }
    }
}
