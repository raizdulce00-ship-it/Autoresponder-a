package com.example.autoresponder

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    var enabled: Boolean
        get() = sp.getBoolean("enabled", false)
        set(v) = sp.edit().putBoolean("enabled", v).apply()

    var script: String
        get() = sp.getString("script", DEFAULT_SCRIPT) ?: DEFAULT_SCRIPT
        set(v) = sp.edit().putString("script", v).apply()

    // Contactos a los que NUNCA se responde (uno por línea, nombre o número)
    var excluded: String
        get() = sp.getString("excluded", "") ?: ""
        set(v) = sp.edit().putString("excluded", v).apply()

    // Si no está vacío, SOLO se responde a estos contactos
    var only: String
        get() = sp.getString("only", "") ?: ""
        set(v) = sp.edit().putString("only", v).apply()

    // Segundos mínimos entre dos respuestas al mismo contacto
    var minSeconds: Int
        get() = sp.getInt("minSeconds", 2)
        set(v) = sp.edit().putInt("minSeconds", v).apply()

    // Minutos que dura la conversación del menú antes de volver al inicio
    var sessionMin: Int
        get() = sp.getInt("sessionMin", 30)
        set(v) = sp.edit().putInt("sessionMin", v).apply()

    var hourFrom: Int
        get() = sp.getInt("hourFrom", 0)
        set(v) = sp.edit().putInt("hourFrom", v).apply()

    var hourTo: Int
        get() = sp.getInt("hourTo", 0)
        set(v) = sp.edit().putInt("hourTo", v).apply()

    companion object {
        val DEFAULT_SCRIPT = """
// @nombre = una pantalla. La primera (o @inicio) es el menú principal.
// ? = palabras que activan la pantalla.  > tecla | texto | destino = opción
@inicio
? hola, buenas, buen dia, buenas tardes, menu, ayuda
Hola {nombre} 👋 Soy el asistente automático. ¿En qué te puedo ayudar?
> 1 | Precios 💲 | precios
> 2 | Horarios 🕒 | horarios
> 3 | Reservar un turno 📅 | turno
> 4 | Hablar con una persona 🙋 | persona

@precios
? precio, precios, cuanto sale, cuanto cuesta, valor
Estos son nuestros precios 💲 Elegí qué te interesa:
> 1 | Productos | productos
> 2 | Servicios | servicios

@productos
Productos 🛍️
Ejemplo: Producto A $1000 · Producto B $1500
Catálogo con fotos 📸 https://tu-sitio.com/catalogo.jpg

@servicios
Servicios 🛠️
Ejemplo: Servicio básico $3000 · Servicio completo $5000

@horarios
? horario, horarios, hora, abren, cierran, atienden
Atendemos de lunes a viernes de 9 a 18 hs 🕒 y sábados de 9 a 13 hs.

@turno
? turno, turnos, reservar, reserva, agenda
Reservá tu turno desde acá 👇
https://tu-sitio.com/agenda.html

@persona
? persona, humano, asesor, atencion
Perfecto 🙌 En cuanto pueda te respondo personalmente.

@fallback
No entendí tu mensaje 😅 Probá con una de estas opciones:
""".trimIndent()
    }
}
