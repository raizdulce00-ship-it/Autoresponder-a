package com.example.autoresponder

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    var enabled: Boolean
        get() = sp.getBoolean("enabled", false)
        set(v) = sp.edit().putBoolean("enabled", v).apply()

    // Respuesta por defecto (vacía = no responde si no coincide ninguna regla)
    var defaultReply: String
        get() = sp.getString("default", "Hola! Ahora no puedo responder, te escribo apenas pueda.") ?: ""
        set(v) = sp.edit().putString("default", v).apply()

    // Una regla por línea: palabra=respuesta
    var rules: String
        get() = sp.getString("rules", "precio=Los precios están en nuestro catálogo, te lo paso enseguida.\nhorario=Atendemos de lunes a viernes de 9 a 18 hs.") ?: ""
        set(v) = sp.edit().putString("rules", v).apply()

    // Minutos sin volver a responder al mismo contacto
    var cooldownMin: Int
        get() = sp.getInt("cooldown", 60)
        set(v) = sp.edit().putInt("cooldown", v).apply()
}
