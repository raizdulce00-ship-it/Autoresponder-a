package com.example.autoresponder

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    private fun str(k: String, d: String) = sp.getString(k, d) ?: d
    private fun putStr(k: String, v: String) = sp.edit().putString(k, v).apply()
    private fun putInt(k: String, v: Int) = sp.edit().putInt(k, v).apply()
    private fun putBool(k: String, v: Boolean) = sp.edit().putBoolean(k, v).apply()

    var enabled: Boolean
        get() = sp.getBoolean("enabled", false)
        set(v) = putBool("enabled", v)

    var useWa: Boolean
        get() = sp.getBoolean("useWa", true)
        set(v) = putBool("useWa", v)

    var useBiz: Boolean
        get() = sp.getBoolean("useBiz", true)
        set(v) = putBool("useBiz", v)

    // Reglas y menús, en formato de notas
    var script: String
        get() = str("script2", DEFAULT_SCRIPT)
        set(v) = putStr("script2", v)

    // Contactos a los que NUNCA se responde ("Nombre|dígitos" por línea)
    var excluded: String
        get() = str("excluded", "")
        set(v) = putStr("excluded", v)

    // Si hay alguno, SOLO se responde a estos
    var only: String
        get() = str("only", "")
        set(v) = putStr("only", v)

    var minSeconds: Int
        get() = sp.getInt("minSeconds", 2)
        set(v) = putInt("minSeconds", v)

    var sessionMin: Int
        get() = sp.getInt("sessionMin", 30)
        set(v) = putInt("sessionMin", v)

    var hourFrom: Int
        get() = sp.getInt("hourFrom", 0)
        set(v) = putInt("hourFrom", v)

    var hourTo: Int
        get() = sp.getInt("hourTo", 0)
        set(v) = putInt("hourTo", v)

    companion object {
        val DEFAULT_SCRIPT = """
PANTALLA: Inicio
SI DICEN: hola, buenas, buen dia, buenas tardes, menu, ayuda
RESPONDER: Hola {nombre} 👋 Soy el asistente automático. ¿En qué te puedo ayudar?
OPCION 1: Precios 💲 -> Precios
OPCION 2: Horarios 🕒 -> Horarios
OPCION 3: Reservar un turno 📅 -> Turno
OPCION 4: Hablar con una persona 🙋 -> Persona

PANTALLA: Precios
SI DICEN: precio, precios, cuanto sale, cuanto cuesta, valor
RESPONDER: Estos son nuestros precios 💲
  Producto A $1000
  Producto B $1500
IMAGEN: https://tu-sitio.com/catalogo.jpg

PANTALLA: Horarios
SI DICEN: horario, horarios, hora, abren, cierran, atienden
RESPONDER: Atendemos de lunes a viernes de 9 a 18 hs 🕒

PANTALLA: Turno
SI DICEN: turno, turnos, reservar, reserva, agenda
RESPONDER: Reservá tu turno desde acá 👇
LINK: https://tu-sitio.com/agenda.html

PANTALLA: Persona
SI DICEN: persona, humano, asesor, atencion
RESPONDER: Perfecto 🙌 En cuanto pueda te respondo personalmente.

PANTALLA: Si no entiende
RESPONDER: No entendí tu mensaje 😅 Probá con una de estas opciones:

PANTALLA: Cuando mandan un audio
RESPONDER: Hola {nombre} 🎧 Por ahora no puedo escuchar audios. ¿Me lo podés escribir, por favor? 🙏
""".trimIndent()
    }
}
