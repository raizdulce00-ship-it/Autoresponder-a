package com.example.autoresponder

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.*

class NotesActivity : Activity() {

    private val example = """
PANTALLA: Inicio
SI DICEN: hola, buenas
RESPONDER: Hola {nombre} 👋 ¿En qué te ayudo?
OPCION 1: Precios -> Precios
OPCION 2: Reservar turno -> Turno

PANTALLA: Precios
SI DICEN: precio, cuanto sale
RESPONDER: Nuestros precios 💲
  Producto A $1000
  Producto B $1500
IMAGEN: https://sitio.com/foto.jpg

PANTALLA: Turno
SI DICEN: turno, reservar
RESPONDER: Reservá acá 👇
LINK: https://sitio.com/agenda.html
""".trimIndent()

    private val help = """
Escribí tus reglas como notas y tocá "Aplicar".

• PANTALLA: nombre de la regla. La primera es el menú principal.
• SI DICEN: palabras que la activan, separadas por coma.
• RESPONDER: el mensaje. Si sigue en más líneas, empezalas con 2 espacios.
• LINK: texto | https://... (el texto es opcional)
• IMAGEN: https://...jpg
• OPCION 1: texto del botón -> nombre de otra regla
• Las líneas que empiezan con // son comentarios.
• {nombre} se reemplaza por el nombre del contacto.

El cliente escribe 0 para volver y # para ir al menú principal.

Ejemplo:

""".trimIndent() + "\n" + example

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Reglas en formato notas"
        val prefs = Prefs(this)
        val col = Ui.page(this)

        col.addView(Ui.note(this, "Acá ves todas tus reglas como texto. Podés editarlas, pegar notas que armaste en otro lado y tocar Aplicar."))
        val et = EditText(this)
        et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        et.minLines = 18
        et.gravity = Gravity.TOP
        et.typeface = Typeface.MONOSPACE
        et.textSize = 13f
        et.setText(prefs.script)
        col.addView(et)

        col.addView(Ui.btn(this, "✅ Aplicar notas") {
            val s = Parser.parse(et.text.toString())
            if (s.nodes.isEmpty()) {
                Ui.toast(this, "No encontré ninguna regla. Cada una empieza con PANTALLA:")
            } else {
                Store.save(prefs, s.nodes.values.toList())
                et.setText(prefs.script)
                Ui.toast(this, "Listo: ${s.nodes.size} reglas cargadas")
            }
        })
        col.addView(Ui.btn(this, "❓ Cómo se escriben") {
            val tv = TextView(this)
            tv.text = help
            tv.setTextIsSelectable(true)
            val p = Ui.dp(this, 16)
            tv.setPadding(p, p, p, p)
            AlertDialog.Builder(this).setView(ScrollView(this).also { it.addView(tv) })
                .setPositiveButton("OK", null).show()
        })
        col.addView(Ui.btn(this, "📋 Copiar") {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("reglas", et.text.toString()))
            Ui.toast(this, "Copiado")
        })
        col.addView(Ui.btn(this, "↩️ Volver al ejemplo inicial") {
            AlertDialog.Builder(this).setTitle("¿Borrar todo y volver al ejemplo?")
                .setPositiveButton("Sí") { _, _ ->
                    prefs.script = Prefs.DEFAULT_SCRIPT
                    et.setText(prefs.script)
                }
                .setNegativeButton("No", null).show()
        })
    }
}
